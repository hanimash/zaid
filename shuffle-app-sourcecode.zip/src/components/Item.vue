<template>
  <div :class="{ Item: true, show, 'flip-card': true }">
    <div class="flip-card-inner">
      <div
        class="flip-card-front"
        :style="{ backgroundColor: color }"
        @click="show = true"
      >
        {{ index }}
      </div>
      <div class="flip-card-back" :style="{ backgroundColor: color }">
        <div class="item-name" @click="show = false">{{ name }}</div>
        <div class="stop-watch">
          <div
            class="time"
            :class="{ hideText: formattedElapsedTime == '00:00' }"
          >
            {{ formattedElapsedTime }}
          </div>
          <div>
            <button class="b-controll b-start" @click="start">&#9654;</button>
            <button
              class="b-controll b-pause"
              :class="{ hideBtn: formattedElapsedTime == '00:00' }"
              @click="pause"
            >
              &#10074;&#10074;
            </button>
            <button
              class="b-controll b-stop"
              :class="{ hideBtn: formattedElapsedTime == '00:00' }"
              @click="stop"
            >
              &#8718;
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// import moment from "moment";
export default {
  name: "Item",
  props: {
    name: String,
    color: String,
    index: Number,
    reset: Boolean,
  },
  data() {
    return {
      show: false,
      elapsedTime: 0,
      timer: undefined,
    };
  },
  computed: {
    formattedElapsedTime() {
      const date = new Date(null);
      date.setSeconds(this.elapsedTime / 1000);
      const utc = date.toUTCString();
      return utc.substr(utc.indexOf(":") + 1, 5);
    },
  },
  methods: {
    start() {
      this.timer = setInterval(() => {
        this.elapsedTime += 1000;
      }, 1000);
    },
    pause() {
      clearInterval(this.timer);
    },
    stop() {
      this.elapsedTime = 0;
      this.pause();
    },
  },
  watch: {
    reset(newValue, oldValue) {
      if (newValue != oldValue) {
        this.show = false;
        this.stop();
      }
    },
    show(newValue, oldValue) {
      if (newValue != oldValue) {
        this.stop();
      }
    },
  },
};
</script>

<style scoped>
.Item {
  width: 230px;
  height: 160px;
  text-align: center;
  margin: 10px;
  cursor: pointer;
}
.flip-card {
  background-color: transparent;
  width: 230px;
  height: 230px;
  perspective: 1000px;
  background-color: transparent;
}

.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.6s;
  transform-style: preserve-3d;
}

.flip-card.show .flip-card-inner {
  transform: rotateY(180deg);
}

.flip-card-front,
.flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 2em;
  border-radius: 10px;
}

.flip-card-front {
  color: rgba(255, 255, 255, 0.2);
  font-weight: 900;
  font-size: 3em;
}

.flip-card-back {
  background-color: #2980b9;
  color: #000;
  transform: rotateY(180deg);
  flex-direction: column;
  justify-content: flex-start;
}
.flip-card-back .item-name {
  padding-top: 30px;
  position: absolute;
  top: 8px;
  left: 0;
  width: 100%;
  height: 70%;
  background: transparent;
  z-index: 10;
}
.stop-watch {
  width: 100%;
  font-size: 14px;
  padding: 10px 0;
  margin-top: 20px;
  position: absolute;
  bottom: 0;
  left: 0;
}
.time {
  font-family: "Comforter", cursive;
  font-size: 4.5em;
  color: #fff;
  opacity: 0.4;
  width: 100%;
  text-align: center;
  transition: opacity 0.2s ease-in-out;
}
.time.hideText {
  opacity: 0;
}
.b-controll.hideBtn {
  display: none;
}
.b-controll {
  margin: 0 3px;
  width: 30px;
  height: 30px;
  background: rgba(255, 255, 255, 0.2);
  border: none;
  cursor: pointer;
}
.b-controll.b-stop {
  font-size: 1.2em;
  line-height: 0.3em;
}
/* .Item h1 {
  width: 100%;
  height: 100%;
  opacity: 0;
  transition: all 0.5s ease-in-out;
}
.Item.show h1 {
  opacity: 1;
} */
</style>
