<template>
  <b-container class="Setting" fluid>
    <b-tabs content-class="mt-3" fill v-model="tabIndex">
      <b-tab :title="isEdit ? 'تعديل : ' + isEdit : 'إضافة صف جديد'">
        <b-container>
          <b-row>
            <b-form>
              <b-form-group
                id="input-group-1"
                label="اسم الصف"
                label-for="input-className"
                description="يجب أن لا يتكرر اسم الصف"
                class="my-3"
              >
                <b-form-input
                  id="input-className"
                  v-model="className"
                  type="text"
                  placeholder="اكتب اسم الصف"
                  required
                  size="sm"
                ></b-form-input>
              </b-form-group>
              <b-form-group
                id="input-group-2"
                label="اسماء البطاقات"
                label-for="textarea-list"
                label-cols-sm="12"
              >
                <b-row>
                  <b-col cols="10">
                    <b-form-input
                      v-model="text"
                      placeholder="أدخل الاسم"
                      @keyup.enter="addItme"
                    ></b-form-input>
                  </b-col>
                  <b-col cols="2">
                    <b-button
                      variant="outline-primary"
                      @click.prevent="addItme"
                      class="w-100"
                      >إضافة</b-button
                    >
                  </b-col>
                </b-row>
              </b-form-group>
              <b-list-group horizontal class="p-3" style="flex-wrap: wrap">
                <b-list-group-item
                  v-for="item in items"
                  :key="item"
                  style="
                    border: 1px solid #eee;
                    margin: 0 5px 5px 5px;
                    position: relative;
                    padding-right: 28px;
                  "
                  ><b-icon
                    icon="x"
                    @click="() => delItem(item)"
                    class="item-del"
                  />{{ item }}</b-list-group-item
                >
              </b-list-group>

              <b-button variant="primary" @click="saveData" class="border-muted"
                >حفظ البيانات</b-button
              >
              <b-button variant="dشnger" @click="cancel" class="border-muted"
                >إلغاء</b-button
              >
            </b-form>
            <p class="p-3" style="font-size: 0.8em">
              ملاحظة: يتم حفظ البيانات على ذاكرة المتصفح. لذلك يمكن أن تحذف
              البيانات في حال حذف بيانات التصفح!!
            </p>
          </b-row>
        </b-container>
        <b-modal ref="error-modal" hide-footer title="خطأ">
          <div class="d-block text-center">
            <p>{{ errorMsg }}</p>
          </div>
          <b-button
            class="mt-3"
            variant="outline-danger"
            block
            @click="hideModal"
            >إغلاق</b-button
          >
        </b-modal>
      </b-tab>
      <b-tab
        title="الصفوف المحفوظة"
        v-if="ClassesList && ClassesList.length > 0"
      >
        <b-container class="mb-4">
          <b-row class="list-header">
            <b-col><h6>الاسم</h6></b-col>
            <b-col cols="6"><h6>البطاقات</h6></b-col>
            <b-col> </b-col>
          </b-row>
          <b-row
            v-for="(c, i) in ClassesList"
            :key="i"
            :class="{
              active: activeClass == c.className,
              'border-bottom': true,
              'p-2': true,
            }"
          >
            <b-col class="pt-1">{{ c.className }}</b-col>
            <b-col cols="6">
              <b-list-group horizontal style="flex-wrap: wrap">
                <b-list-group-item
                  v-for="item in c.items"
                  :key="item"
                  style="border: 1px solid #eee; margin: 0 5px 5px 5px"
                  >{{ item }}</b-list-group-item
                >
              </b-list-group>
            </b-col>
            <b-col class="pt-1">
              <b-button
                size="sm"
                variant="denger"
                @click="editClass(c.className)"
              >
                <b-icon icon="pencil-fill" />
              </b-button>
              <b-button
                size="sm"
                variant="denger"
                @click="delClass(c.className)"
              >
                <b-icon icon="trash" />
              </b-button>
              <b-button
                size="sm"
                variant="denger"
                @click="setActiveClass(c.className)"
              >
                <b-icon icon="circle" v-if="c.className != activeClass" />
                <b-icon icon="check-circle" v-if="c.className == activeClass" />
              </b-button>
            </b-col>
          </b-row>
        </b-container>
      </b-tab>
    </b-tabs>
  </b-container>
</template>

<script>
export default {
  name: "Setting",

  data() {
    return {
      tabIndex: 0,
      className: "",
      activeClass: "",
      ClassesList: [],
      errorMsg: "",
      text: "",
      items: [],
      isEdit: null,
    };
  },
  mounted() {
    this.getLocalStorage();
  },
  methods: {
    saveData() {
      if (this.className == "") {
        this.showModal("الرجاء إضافة اسم الصف!");
        return;
      }
      if (!this.items || this.items.length <= 0) {
        this.showModal("الرجاء إضافة اسماء البطاقات!!");
        return;
      }
      this.getLocalStorage();
      if (this.isEdit) {
        this.delClass(this.isEdit);
      }
      if(this.ClassesList.filter(cl=>cl.className==this.className).length>0){
        this.showModal("اسم الصف مستخدم من قبل يرجى ادخال اسم آخر!!");
        return;
      }
      var cList = [
        ...this.ClassesList,
        { className: this.className, items: this.items },
      ];
      this.ClassesList = cList;
      this.activeClass = this.className;
      this.className = "";
      this.items = [];
      this.isEdit = null;
      this.tabIndex = 1;
      this.setLocalStorage();
      this.getLocalStorage();
    },
    cancel() {
      this.className = "";
      this.items = [];
      this.isEdit = null;
      this.tabIndex = 1;
    },
    addItme() {
      if (this.text == "") {
        this.showModal("الرجاءإضافة الاسم");
        return;
      }
      if (this.items.indexOf(this.text) >= 0) {
        this.showModal("الاسم موجود بالفعل");
        return;
      }
      this.items.push(this.text);
      this.text = "";
    },
    delItem(item) {
      this.items = this.items.filter((i) => i != item);
    },
    getLocalStorage() {
      if (
        localStorage.getItem("ClassesList") &&
        localStorage.getItem("activeClass")
      ) {
        this.ClassesList = JSON.parse(localStorage.getItem("ClassesList"));
        this.activeClass = JSON.parse(localStorage.getItem("activeClass"));
      } else {
        this.ClassesList = [];
        this.activeClass = "";
      }
    },
    setLocalStorage() {
      localStorage.setItem("ClassesList", JSON.stringify(this.ClassesList));
      localStorage.setItem("activeClass", JSON.stringify(this.activeClass));
    },
    delClass(cName) {
      this.getLocalStorage();
      this.ClassesList = this.ClassesList.filter((c) => c.className != cName);
      if (this.activeClass == cName) {
        if (this.ClassesList.length > 0)
          this.activeClass = this.ClassesList[0].className;
        else this.activeClass = "";
      }
      this.setLocalStorage();
    },
    editClass(cName) {
      this.isEdit = cName;
      this.className = cName;
      this.items = this.ClassesList.filter(
        (c) => c.className == cName
      )[0].items;
      this.tabIndex = 0;
    },
    setActiveClass(cName) {
      this.getLocalStorage();
      this.activeClass = cName;
      this.setLocalStorage();
    },
    showModal(msg) {
      this.errorMsg = msg;
      this.$refs["error-modal"].show();
    },
    hideModal() {
      this.errorMsg = "";
      this.$refs["error-modal"].hide();
    },
  },
};
</script>

<style scoped>
.Setting {
  direction: rtl;
  text-align: right;
  padding: 0;
}

.list-header {
  border-bottom: 1px solid #000;
}
.item-del {
  position: absolute;
  top: 0;
  right: 0;
  background: rgba(191, 85, 85, 0.453);
  color: #fff;
}
</style>
